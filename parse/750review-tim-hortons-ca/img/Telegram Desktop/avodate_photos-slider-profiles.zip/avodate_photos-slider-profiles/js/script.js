$(document).ready(function(){
    $('.reviews').slick({
        fade: true,
        arrows: true,
        dots: true,
        autoplay: true,
        autoplaySpeed: 7500,
        prevArrow: "<button class='arrow prev'><i class='fa-solid fa-arrow-left-long'></i></button>",
        nextArrow: "<button class='arrow next'><i class='fa-solid fa-arrow-right-long'></i></button>",
        appendArrows: ".slider-nav",
        appendDots: ".slider-nav"
    })


    function shuffleSlides() {
        const wrapper = document.querySelector('.swiper-wrapper');
        const slides = Array.from(wrapper.children);

        for (let i = slides.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            wrapper.appendChild(slides[j]);
            slides.splice(j, 1);
        }
    }
    shuffleSlides();

    let slideFirst = `<div class="swiper-slide swiper-slide--placeholder swiper-slide--placeholder-first"></div>`
    let slideLast = `<div class="swiper-slide swiper-slide--placeholder swiper-slide--placeholder-last"></div>`
    $(".swiper-wrapper").append(slideLast);
    $(".swiper-wrapper").prepend(slideFirst);

    // const swiper = new Swiper('.swiper', {
    //     // loop: true,
    //     centeredSlides: true,
    //     centeredSlidesBounds: true,
    //     spaceBetween: 20,
    //     speed: 750,
    //     initialSlide: Math.floor(document.querySelectorAll('.swiper-slide').length / 2),
    //     breakpoints: {
    //         0: {
    //             slidesPerView: 1.5,
    //         },
    //         768: {
    //             slidesPerView: 2.5,
    //         }
    //     }
    // });

     const swiper = new Swiper('.swiper', {
        effect: 'coverflow',
        // loop: true,
        centeredSlides: true,
        centeredSlidesBounds: true,
        grabCursor: true,
        initialSlide: Math.floor(document.querySelectorAll('.swiper-slide').length / 2),
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        speed: 750,
        coverflowEffect: {
            rotate: 30,
            stretch: 0,
            depth: 100,
            modifier: 1,
            slideShadows: true,
        },
        breakpoints: {
            0: {
                slidesPerView: 1.5,
                spaceBetween: 5,
            },
            768: {
                spaceBetween: 10,
                slidesPerView: 2.5,

            }
        }
    });
    
})