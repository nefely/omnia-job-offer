$(document).ready(function(){
    function shuffleSlides() {
        const wrapper = document.querySelector('.swiper-wrapper');
        const slides = Array.from(wrapper.children);

        for (let i = slides.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            wrapper.appendChild(slides[j]);
            slides.splice(j, 1);
        }
    }
    shuffleSlides();

    let slideFirst = `<div class="swiper-slide swiper-slide--placeholder swiper-slide--placeholder-first"></div>`
    let slideLast = `<div class="swiper-slide swiper-slide--placeholder swiper-slide--placeholder-last"></div>`
    $(".swiper-wrapper").append(slideLast);
    $(".swiper-wrapper").prepend(slideFirst);

    const swiper = new Swiper('.swiper', {
        effect: 'coverflow',
        // loop: true,
        centeredSlides: true,
        centeredSlidesBounds: true,
        grabCursor: true,
        initialSlide: Math.floor(document.querySelectorAll('.swiper-slide').length / 2),
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        speed: 750,
        coverflowEffect: {
            rotate: 30,
            stretch: 0,
            depth: 100,
            modifier: 1,
            slideShadows: true,
        },
        breakpoints: {
            0: {
                slidesPerView: 1.5,
                spaceBetween: 5,
            },
            768: {
                spaceBetween: 10,
                slidesPerView: 2.5,

            }
        }
    });
    
})